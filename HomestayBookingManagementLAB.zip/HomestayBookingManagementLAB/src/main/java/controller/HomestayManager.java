/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import data.HomestayDAO;
import model.Homestay;
import java.util.List;
import utils.Inputter;
/**
 *
 * @author rechiee
 */
public class HomestayManager {
    private List<Homestay> list;
    private HomestayDAO dao;

    public HomestayManager() {
        dao = new HomestayDAO();
        list = dao.readData();
    }

    public Homestay searchHomestay(String id) {
        for (Homestay h : list) {
            if (h.getHomeID().equalsIgnoreCase(id)) return h;
        }
        return null;
    }
    public void  searchByCity(){
        System.out.println("--SearchByCity--");
        String city = Inputter.inputString("Enter city: ", false).toLowerCase();
        boolean found = false;
        for(Homestay h : list){
            if(h.getAddress().toLowerCase().contains(city)){
                h.showInfo();
                found= true;
            }
        }
        if(!found){
            System.out.println("No Found");
        }
    }
    public void searchByCapacity() {
        System.out.println("\n--- SEARCH HOMESTAY BY CAPACITY ---");
        // Nhập số người cần tìm (Validation số dương)
        int numPeople = utils.Inputter.inputInt("Enter number of people in your group: ", 1,99);
        
        System.out.println("Here are suitable homestays for " + numPeople + " people:");
        System.out.println("--------------------------------------------------------------------------------------");
        // In lại header bảng cho đẹp
        System.out.printf("| %-6s | %-25s | %-5s | %-30s | %-8s |\n", "ID", "Name", "Room", "Address", "Capacity");
        System.out.println("--------------------------------------------------------------------------------------");
        
        boolean found = false;
        for (model.Homestay h : list) {
            // Logic: Chỉ hiện những homestay chứa ĐỦ hoặc NHIỀU HƠN số người yêu cầu
            if (h.getMaxCapacity() >= numPeople) {
                // Tự in ra format dòng (vì hàm showInfo cũ của cậu có cột Price thừa)
                System.out.printf("| %-6s | %-25s | %-5d | %-30s | %-8d |\n", 
                        h.getHomeID(), h.getHomeName(), h.getRoomNumber(), h.getAddress(), h.getMaxCapacity());
                found = true;
            }
        }
        
        if (!found) {
            System.out.println("|                            NO HOMESTAY FOUND                                       |");
        }
        System.out.println("--------------------------------------------------------------------------------------");
    }

    public void displayAll() {
        System.out.println("\n--- HOMESTAY LIST ---");
        for (Homestay h : list) h.showInfo();
    }
}
