package controller;

/*
 * TourManager.java
 */
import data.TourDAO; 
// -----------------------------
import model.Homestay;
import model.Tour;
import utils.DateUtils;
import utils.Inputter;
import java.util.Date;
import java.util.List;

/**
 *
 * @author rechiee
 */
public class TourManager {
    private List<Tour> tours;
    private TourDAO dao;
    private HomestayManager hMgr; // DI

    public TourManager(HomestayManager hMgr) {
        this.hMgr = hMgr;
        this.dao = new TourDAO();
        this.tours = dao.readData();
    }

    private boolean isExist(String id) {
        for (Tour t : tours) if (t.getTourID().equalsIgnoreCase(id)) return true;
        return false;
    }
    
    private Tour findTour(String id) {
        for (Tour t : tours) if (t.getTourID().equalsIgnoreCase(id)) return t;
        return null;
    }

    private boolean isOverlap(String homeID, Date start, Date end) {
        for (Tour t : tours) {
            if (t.getHomeID().equalsIgnoreCase(homeID)) {
                if (DateUtils.isOverlap(start, end, t.getDepartureDate(), t.getEndDate())) return true;
            }
        }
        return false;
    }

    public void addTour() {
        System.out.println("\n--- ADD NEW TOUR ---");
        String id;
        while(true) {
            id = Inputter.inputString("Enter Tour ID: ", false);
            if(!isExist(id)) break;
            System.err.println("Existed!");
        }
        String name = Inputter.inputString("Enter Name: ", false);
        String dur = Inputter.inputString("Enter Duration: ", false);
        double price = Inputter.inputDouble("Enter Price: ", 0);

        hMgr.displayAll();
        String hID;
        Homestay home;
        while(true) {
            hID = Inputter.inputString("Enter Home ID: ", false);
            home = hMgr.searchHomestay(hID);
            if(home != null) break;
            System.err.println("Not Found!");
        }

        Date start, end;
        while(true) {
            start = Inputter.inputDate("Start Date");
            end = Inputter.inputDate("End Date");
            if(end.before(start)) { System.err.println("End >= Start!"); continue; }
            if(isOverlap(hID, start, end)) { System.err.println("Homestay Busy!"); } 
            else break;
        }

        int num = Inputter.inputInt("Num Tourist: ", 1, home.getMaxCapacity());

        Tour t = new Tour(id, name, dur, price, hID, start, end, num, "Booked");
        tours.add(t);
        dao.writeData(tours);
        System.out.println("Success!");
    }

    
    
    public void updateTour() {
        System.out.println("\n--- UPDATE TOUR ---");
        String id = Inputter.inputString("Enter Tour ID to update: ", false);
        Tour t = findTour(id);
        if(t == null) {
            System.err.println("Tour not found!");
            return;
        }

        System.out.println("Note: Press Enter to keep old value.");
        
        // 1. Update Name
        String newName = Inputter.inputString("New Name [" + t.getTourName() + "]: ", true);
        if(!newName.isEmpty()) t.setTourName(newName);

        // 2. Update Duration
        String newDur = Inputter.inputString("New Duration [" + t.getDuration() + "]: ", true);
        if(!newDur.isEmpty()) t.setDuration(newDur);

        // 3. Update Num Tourist
        System.out.println("Old Num Tourist: " + t.getNumberTourist());
        String numStr = Inputter.inputString("New Num Tourist (Enter to skip): ", true);
        if(!numStr.isEmpty()) {
             try {
                 int n = Integer.parseInt(numStr);
                 if(n > 0) t.setNumberTourist(n);
             } catch(Exception e) { System.err.println("Invalid number, keeping old value."); }
        }

        dao.writeData(tours); // Lưu lại
        System.out.println("Updated!");
    }

    // [MỚI] Chức năng xóa Tour
    public void deleteTour() {
        System.out.println("\n--- DELETE TOUR ---");
        String id = Inputter.inputString("Enter Tour ID to delete: ", false);
        Tour t = findTour(id);
        
        if (t == null) {
            System.err.println("Tour not found!");
        } else {
            tours.remove(t);
            dao.writeData(tours); // Cập nhật file ngay
            System.out.println("Deleted successfully!");
        }
    }

    public void displayTours() {
        System.out.println("\n--- TOUR LIST ---");
        if(tours.isEmpty()) System.out.println("List Empty.");
        for(Tour t : tours) t.showInfo();
    }

    
}