/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import controller.HomestayManager;
import controller.TourManager;
import view.Menu;

public class Main {
    public static void main(String[] args) {
        // Wiring Controllers
        HomestayManager hMgr = new HomestayManager();
        TourManager tMgr = new TourManager(hMgr); // Inject HomestayMgr vào TourMgr

        Menu m = new Menu("HOMESTAY BOOKING SYSTEM");
        m.addOption("Display all Homestays");
        m.addOption("Search Homestay by City"); // Mới
        m.addOption("Search Homestay by Price");
        m.addOption("Display all Tours");
        m.addOption("Book a new Tour");
        m.addOption("Update Tour");             // Mới
        m.addOption("Delete Tour");             // Mới
        m.addOption("Exit");

        while(true) {
            switch(m.getChoice()) {
                case 1: hMgr.displayAll(); break;
                case 2: hMgr.searchByCity(); break;
                case 3: hMgr.searchByPrice(); break;
                case 4: tMgr.displayTours(); break;
                case 5: tMgr.addTour(); break;
                case 6: tMgr.updateTour(); break;
                case 7: tMgr.deleteTour(); break;
                case 8: 
                    System.out.println("Goodbye!");
                    return;
            }
        }
    }
}

