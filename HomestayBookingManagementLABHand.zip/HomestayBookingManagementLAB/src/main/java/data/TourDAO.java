/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;

import model.Tour;
import utils.DateUtils;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author rechiee
 */
public class TourDAO implements IFileReadWrite<Tour> {
    private final String FILE_NAME = "Tours.txt";
    
    @Override
    public List<Tour> readData() {
        List<Tour> list = new ArrayList<>();
        File f = new File(FILE_NAME);
        
        // 1. Kiểm tra file tồn tại
        if (!f.exists()) {
            System.err.println("⚠️ CẢNH BÁO: Không tìm thấy file Tours.txt tại: " + f.getAbsolutePath());
            return list;
        }

        // 2. Đọc file với chuẩn UTF-8 (Quan trọng!)
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                // Bỏ qua dòng trống
                if (line.trim().isEmpty()) continue;

                // Cắt chuỗi bằng dấu phẩy
                String[] p = line.split(",");
                
                // Debug: In ra để xem nó đọc được gì (Nếu lỗi thì chụp màn hình dòng này gửi tớ)
                // System.out.println("Reading line: " + line); 

                if (p.length >= 9) {
                    try {
                        String id = p[0].trim();
                        String name = p[1].trim();
                        String duration = p[2].trim();
                        double price = Double.parseDouble(p[3].trim());
                        String homeID = p[4].trim();
                        java.util.Date start = DateUtils.parseDate(p[5].trim());
                        java.util.Date end = DateUtils.parseDate(p[6].trim());
                        int num = Integer.parseInt(p[7].trim());
                        String status = p[8].trim();

                        list.add(new Tour(id, name, duration, price, homeID, start, end, num, status));
                    } catch (Exception e) {
                        System.err.println("❌ Lỗi định dạng dòng này: " + line);
                        System.err.println("   -> Chi tiết lỗi: " + e.getMessage());
                    }
                } else {
                    System.err.println("⚠️ Dòng thiếu dữ liệu (Cần 9 cột, có " + p.length + "): " + line);
                }
            }
        } catch (Exception e) {
            System.err.println("❌ Lỗi đọc file Tour: " + e.getMessage());
        }
        return list;
    }

    @Override
    public void writeData(List<Tour> list) {
        // Ghi file cũng ép UTF-8 cho đồng bộ
        try (PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(FILE_NAME), StandardCharsets.UTF_8))) {
            for (Tour t : list) {
                pw.println(t.toString());
            }
        } catch (IOException e) {
            System.err.println("Save error: " + e.getMessage());
        }
    }
}
//public class TourDAO implements IFileReadWrite<Tour> {
//    private final String FILE_NAME = "Tours.txt";
//    
//    @Override
//    public List<Tour> readData() {
//        List<Tour> list = new ArrayList<>();
//        File f = new File(FILE_NAME);
//        if (!f.exists()) return list;
//        
//       
//        
//        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
//            String line;
//            while ((line = br.readLine()) != null) {
//                String[] p = line.split(",");
//                if (p.length >= 9) {
//                    list.add(new Tour(p[0].trim(), p[1].trim(), p[2].trim(), Double.parseDouble(p[3].trim()), p[4].trim(),
//                            DateUtils.parseDate(p[5].trim()), DateUtils.parseDate(p[6].trim()), 
//                            Integer.parseInt(p[7].trim()), p[8].trim()));
//                }
//            }
//        } catch (Exception e) {
//            System.err.println("Load Tour Error: " + e.getMessage());
//        }
//        return list;
//    }
//
//    @Override
//    public void writeData(List<Tour> list) {
//        try (PrintWriter pw = new PrintWriter(new FileWriter(FILE_NAME))) {
//            for (Tour t : list) pw.println(t.toString());
//        } catch (IOException e) {
//            System.err.println("Save error: " + e.getMessage());
//        }
//    }
//}