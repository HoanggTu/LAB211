/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import data.HomestayDAO;
import model.Homestay;
import java.util.List;
import utils.Inputter;
/**
 *
 * @author rechiee
 */
public class HomestayManager {
    private List<Homestay> list;
    private HomestayDAO dao;

    public HomestayManager() {
        dao = new HomestayDAO();
        list = dao.readData();
    }

    public Homestay searchHomestay(String id) {
        for (Homestay h : list) {
            if (h.getHomeID().equalsIgnoreCase(id)) return h;
        }
        return null;
    }
    public void  searchByCity(){
        System.out.println("--SearchByCity--");
        String city = Inputter.inputString("Enter city: ", false).toLowerCase();
        boolean found = false;
        for(Homestay h : list){
            if(h.getAddress().toLowerCase().contains(city)){
                h.showInfo();
                found= true;
            }
        }
        if(!found){
            System.out.println("No Found");
        }
    }
    public void searchByPrice(){
        System.out.println("--SearchByPrice--");
        double min = Inputter.inputDouble("Enter Min Price: ", 0);
        double max = Inputter.inputDouble("Enter Max Price: ", min);
        System.out.println("--- SEARCH RESULT ---");
        boolean found = false;
        for (Homestay h : list) {
            if (h.getPrice() >= min && h.getPrice() <= max) {
                h.showInfo();
                found = true;
            }
        }
        if (!found) System.out.println("No found");
    }

    public void displayAll() {
        System.out.println("\n--- HOMESTAY LIST ---");
        for (Homestay h : list) h.showInfo();
    }
}
